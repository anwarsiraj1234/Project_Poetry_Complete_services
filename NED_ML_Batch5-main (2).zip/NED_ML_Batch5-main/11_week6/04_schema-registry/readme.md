# 02_kafka_messaging

https://github.com/aio-libs/aiokafka